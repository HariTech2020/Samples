﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVC_RazorSampleApp.Models
{
    public class Movies
    {
        public int Rank { get; set; }
        public string Title { get; set; }
        public int ReleasedYear { get; set; }
    }
}
