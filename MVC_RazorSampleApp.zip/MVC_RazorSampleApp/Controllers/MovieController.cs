﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_RazorSampleApp.Models;

namespace MVC_RazorSampleApp.Controllers
{
    public class MovieController : Controller
    {
        public IActionResult Index()
        {
            List<Movies> _list0fMovies = new List<Movies>();
            _list0fMovies.Add(new Movies { Rank = 1, Title = "Avengers", ReleasedYear=2018 });
            _list0fMovies.Add(new Movies { Rank = 2, Title = "Spider Man", ReleasedYear = 2017 });
            _list0fMovies.Add(new Movies { Rank = 3, Title = "Batman", ReleasedYear = 2019 });
            _list0fMovies.Add(new Movies { Rank = 4, Title = "Ice Age", ReleasedYear = 2009 });
            _list0fMovies.Add(new Movies { Rank = 5, Title = "Horry Potter", ReleasedYear = 1995 });
            
            return View(_list0fMovies);            
        }
    }
}