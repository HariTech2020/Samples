﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using MVC_RazorSampleApp.Models;

namespace MVC_RazorSampleApp.Controllers
{
    public class StudentController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.Title = "Student Details Page";            
            Student student = new Student()
            {
                RollNo = 5,
                Name = "Hariharan",
                Gender = "Male",
                City="Namakkal",
                Address="ABC 123 Street"
            };
            return View(student);            
        }

        public IActionResult MonthInfo()
        {
            return View();
        }

    }
}